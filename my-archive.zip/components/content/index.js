define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojmutablearraydataprovider", "text!../store_data.json", "ojs/ojlabel", "ojs/ojselectsingle", "ojs/ojchart", "ojs/ojlistview", "ojs/ojlistitemlayout"], function (require, exports, jsx_runtime_1, hooks_1, MutableArrayDataProvider, storeData) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Content = void 0;
    const chartTypeData = [
        { value: "bar", label: "Bar" },
        { value: "pie", label: "Pie" },
    ];
    const chartTypesDP = new MutableArrayDataProvider(chartTypeData, { keyAttributes: "value" });
    const chartData = [
        { id: 0, series: "Baseball", group: "Group A", value: 42 },
        { id: 1, series: "Baseball", group: "Group B", value: 34 },
        { id: 2, series: "Bicycling", group: "Group A", value: 55 },
        { id: 3, series: "Bicycling", group: "Group B", value: 30 },
        { id: 4, series: "Skiing", group: "Group A", value: 36 },
        { id: 5, series: "Skiing", group: "Group B", value: 50 },
        { id: 6, series: "Soccer", group: "Group A", value: 22 },
        { id: 7, series: "Soccer", group: "Group B", value: 46 },
    ];
    const chartDataProvider = new MutableArrayDataProvider(chartData, { keyAttributes: "id" });
    const activityDataProvider = new MutableArrayDataProvider(JSON.parse(storeData), {
        keyAttributes: "id",
    });
    const gridlinesItemVisible = { item: "visible" };
    function Content() {
        const [val, setVal] = (0, hooks_1.useState)("bar");
        const valChangeHandler = (0, hooks_1.useCallback)((event) => {
            setVal(event.detail.value);
        }, [val, setVal]);
        const chartItem = (item) => {
            return ((0, jsx_runtime_1.jsx)("oj-chart-item", { value: item.data.value, groupId: [item.data.group], seriesId: item.data.series }));
        };
        const renderListItem = (item) => {
            return ((0, jsx_runtime_1.jsx)("li", { children: (0, jsx_runtime_1.jsx)("oj-list-item-layout", { children: (0, jsx_runtime_1.jsx)("div", { class: "oj-typography-body-md", children: item.data.name }) }) }));
        };
        return ((0, jsx_runtime_1.jsxs)("div", { class: "oj-web-applayout-max-width oj-web-applayout-content", children: [(0, jsx_runtime_1.jsx)("h1", { children: "Product Information" }), (0, jsx_runtime_1.jsxs)("div", { id: "activitiesContainer", children: [(0, jsx_runtime_1.jsx)("h3", { id: "activitiesHeader", children: "Activities" }), (0, jsx_runtime_1.jsx)("oj-list-view", { id: "activitiesList", "aria-labelledby": "activitiesHeader", data: activityDataProvider, gridlines: gridlinesItemVisible, children: (0, jsx_runtime_1.jsx)("template", { slot: "itemTemplate", render: renderListItem }) })] }), (0, jsx_runtime_1.jsxs)("div", { id: "itemDetailsContainer", children: [(0, jsx_runtime_1.jsx)("h3", { children: "Item Details" }), (0, jsx_runtime_1.jsx)("oj-label", { for: "basicSelect", children: "Choose your Chart:" }), (0, jsx_runtime_1.jsx)("oj-select-single", { id: "basicSelect", class: "selectSingleStyle", data: chartTypesDP, value: val, onvalueChanged: valChangeHandler }), (0, jsx_runtime_1.jsx)("oj-chart", { id: "barChart", type: val, data: chartDataProvider, animationOnDisplay: "auto", animationOnDataChange: "auto", hoverBehavior: "dim", class: "chartStyle", children: (0, jsx_runtime_1.jsx)("template", { slot: "itemTemplate", render: chartItem }) })] })] }));
    }
    exports.Content = Content;
});
